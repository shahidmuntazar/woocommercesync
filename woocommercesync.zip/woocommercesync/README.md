# WooCommerce Product Sync System (Laravel)

This is a Laravel-based application that allows users to register, create products, and sync them directly to a connected WooCommerce store using the WooCommerce REST API.

---

## ✨ Features

- 🔐 JWT-style authentication via Laravel Sanctum
- 🧾 Register/Login
- 📦 Create and list products
- 🔄 Sync products to WooCommerce via API (Basic Auth)
- 💾 Product status tracking: Created, Synced, Failed

---

## 🛠 Tech Stack

- Laravel 10+
- Sanctum (auth)
- MySQL or PostgreSQL
- WooCommerce REST API

---

## 🚀 Installation

### 1. Clone the repository

```bash
git clone https://github.com/yourusername/woocommerce-sync-laravel.git
cd woocommercesync