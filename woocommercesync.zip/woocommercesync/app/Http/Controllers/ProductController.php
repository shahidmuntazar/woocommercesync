<?php
namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        return $request->user()->products()->get();
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string',
            'description' => 'nullable|string',
            'price' => 'required|numeric',
            'image_url' => 'nullable|url',
        ]);

        $product = $request->user()->products()->create($validated);

        $this->syncToWooCommerce($product);

        return response()->json($product->fresh());
    }

    private function syncToWooCommerce(Product $product)
    {
        $response = Http::withBasicAuth(
            config('services.woocommerce.key'),
            config('services.woocommerce.secret')
        )->post(config('services.woocommerce.url') . '/wp-json/wc/v3/products', [
            'name' => $product->name,
            'type' => 'simple',
            'regular_price' => (string) $product->price,
            'description' => $product->description,
            'images' => $product->image_url ? [['src' => $product->image_url]] : [],
        ]);

        if ($response->successful()) {
            $product->update([
                'wc_product_id' => $response['id'],
                'status' => 'Synced',
            ]);
        } else {
            $product->update(['status' => 'Failed']);
            Log::error('WooCommerce Sync Failed', [
                'error' => $response->body(),
                'product_id' => $product->id,
            ]);
        }
    }
}
